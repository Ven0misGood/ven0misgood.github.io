# grindcraft-ven0m
GrindCraft is a Minecraft-themed clicker game based on crafting. Collect various materials and climb the crafting ladder to create stronger items.
Inspired by 3kh0 and made by Ven0m
